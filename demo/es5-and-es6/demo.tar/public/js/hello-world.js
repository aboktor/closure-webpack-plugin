(function(__wpcc){var n, m;
n = function(a, b) {
  function f() {
    d.onerror = d.onload = null;
    clearTimeout(q);
    var g = e[a];
    if (0 !== g) {
      if (g) {
        g[1](Error("Loading chunk " + a + " failed."));
      }
      e[a] = void 0;
    }
  }
  var c = e[a];
  if (0 === c) {
    return b;
  }
  if (c) {
    return c[2];
  }
  var k = (new Promise(function(g, r) {
    c = e[a] = [g, r];
  })).then(function(g) {
    return b.then(function() {
      g && g.call(h, __wpcc);
    });
  });
  c[2] = k;
  var u = document.getElementsByTagName("head")[0], d = document.createElement("script");
  d.type = "text/javascript";
  d.charset = "utf-8";
  d.async = !0;
  d.timeout = 120000;
  __wpcc.nc && 0 < __wpcc.nc.length && d.setAttribute("nonce", __wpcc.nc);
  d.src = (__wpcc.l.p || "") + m[a];
  var q = setTimeout(f, 120000);
  d.onerror = d.onload = f;
  u.appendChild(d);
  return k;
};
m = {};
"undefined" === typeof __wpcc.l && (__wpcc.l = function() {
});
__wpcc.l.p = "";
var h = this, e;
"undefined" === typeof e && (e = {});
(function() {
  var a = window.webpackJsonp;
  window.webpackJsonp = function(b, f) {
    var c, k = [];
    for (c = 0; c < b.length; c++) {
      e[b[c]] && (k.push(e[b[c]][0]), e[b[c]] = 0);
    }
    for (a && a(b, function() {
    }); k.length;) {
      k.shift()(f);
    }
  };
})();
__wpcc.l.e = function() {
  for (var a = Array.prototype.slice.call(arguments), b = Promise.resolve(), f = 0; f < a.length; f++) {
    b = n(a[f], b);
  }
  return b;
};
__wpcc.l.h = function() {
  m[__wpcc.p[__wpcc.t]] = "js/" + ({}[__wpcc.v] || __wpcc.v) + ".js";
};
}).call(this || window, (window.__wpcc = window.__wpcc || {}));

(function(__wpcc){for (__wpcc.p = ["815"], __wpcc.t = 0, __wpcc.v; __wpcc.t < __wpcc.p.length; __wpcc.t++) {
  __wpcc.v = __wpcc.p[__wpcc.t], __wpcc.l.h();
}
;var w = class {
  constructor() {
    this.name = "NAME NAME";
  }
};
document.body.innerText += "Hello World";
console.log((new function(a) {
  this.ok = a;
}(1, 2, 3)).ok);
console.log("private stuff", (new w()).name);
(a => new Promise(b => {
  setTimeout(b, a);
}))(5000).then(() => __wpcc.l.e(815).then(function() {
  return __wpcc.x;
}).then(a => a.g()));
}).call(this || window, (window.__wpcc = window.__wpcc || {}));

//# sourceMappingURL=hello-world.js.map