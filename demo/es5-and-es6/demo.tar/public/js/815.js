webpackJsonp([815], function(__wpcc){__wpcc.x = {g:() => {
  document.body.innerText += "\nDynamic stuff";
}};
});

//# sourceMappingURL=815.js.map