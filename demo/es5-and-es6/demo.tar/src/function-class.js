export function Result (ok, val, err) {
  this.ok = ok;
  this.val = val;
  this.err = err;
}
