export const doDynamicStuff = () => {
  document.body.innerText += "\nDynamic stuff";
}
