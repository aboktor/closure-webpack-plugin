export const doStuff = () => {
  document.body.innerText += "Hello World";
}

export const unused = () => {
  document.body.innerText += "UNUSED";
}
